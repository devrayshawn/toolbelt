


print(__main__.__module__.__doc__)