''' Paired lists are like dictionaries but, as a list. There are a lot of cool (simple) methods
    and this script can be very useful. Its almost like using a dictionary that has list functionality.
    You can add, remove, replace any item or key, value pairs and much more. It's easy to map
    list elements to a dictionary but, what about mapping dictionary elements to a list and
    maintain their positions as a key value pair. When initializing an object of class pairedlist
    , you can access all of the classes information using the '.' fuctionality after initialiizing
    a pairedlist object.
    
    example:
        paired = pairedlist
        paired.key = YOUR_CHOICE
        paired.value = YOUR_CHOICE
'''
__author__ = 'Rayshawn Levy'
from unique import __unique__



class pairedlist(metaclass=__unique__):
    
    
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.lst = []
        self.lst.append(key)
        self.lst.append(value)
        self.extended = []
    
    
    def additem(self, key=None, value=None):
        
        if key is not None and value is not None:
            self.lst.append(key)
            self.list.append(value)
        
        else:
            self.lst.append(self.key)
            self.lst.append(self.value)
        
        return self.lst
    
    
    def delete(self, key):
        
        if type(self.key) in [list, tuple, set] or type(self.value) in [list, tuple, set]:
            for item in self.lst:
                for k in item:
                    
                    if k == key:
                        for keys in range(0, len(item), 2):
                            self.lst.remove(self.lst[keys])
                            self.lst.remove(self.lst[keys])
        
        elif type(self.key) == dict or type(self.value) == dict:
            for item in self.lst:
                for k, v in item.items():
                    
                    if k == key:
                        for keys in range(0, len(item), 2):
                            self.lst.remove(self.lst[keys])
                            self.lst.reomve(self.lst[keys])
        
        else:
            for item in range(0, len(self.lst), 2):
                if self.lst[item] == key:
                    self.lst.remove(key)
                    self.lst.remove(self.lst[item])
                        
        return self.lst
    
    
    def arithmetic(self):
        
        new = None
        for item in self.lst:
            if type(item) in [list, str, tuple, int]:
                
                for items in range(0, len(self.lst), 2):
                    print(self.lst[items]+self.lst[items+1])
                    new = self.lst[items]+self.lst[items+1]
            
            elif type(self.key) not in [list, str, tuple, int] and type(self.key) != type(self.value):
                raise ArithmeticError("Can't 'add' together a {} and {}.".format(type(self.key).__name__, type(self.value).__name__))
        
        return {'original': self.lst, 'results': new}
    
    
    def replace(self, new_key=None, new_value=None, key=None, value=None):
        
        if new_key is not None and new_value is not None and key is not None and value is not None:
            
            self.delete(key)
            self.additem(new_key, new_value)
        
        elif new_key is not None and new_value is None and key is not None and value is None:
            pos = 0
            
            for item in self.lst:
                pos += 1
                
                if type(item) == key:
                    self.lst.remove(self.lst[pos-1])
                    self.lst.insert(pos-1, new_key)
        
        elif new_key is None and new_value is not None and key is None and value is not None:
            
            pos = 0
            
            for item in self.lst:
                pos += 1
                
                if type(item) == value:
                    self.lst.remove(self.lst[pos-1])
                    self.lst.insert(pos-1, new_value)
        
        else:
            raise AttributeError("Nothing to replace.")
        
        return self.lst
    
    
    def length(self, elements=False):
        
        pos = 0
        
        if elements is True:
            
            if type(self.key) in [list, tuple, dict, set] and type(self.value) in [list, tuple, dict, set]:
                
                kgroup = 0
                vgroup = 0
                
                for item in self.key:
                    for i in item:
                        kgroup += 1
                
                for v in self.value:
                    for val in v:
                        vgroup += 1
                    
                return {'key': kgroup, 'value': vgroup, 'total': kgroup+vgroup}
            
            elif type(self.key) in [list, tuple, dict, set] and type(self.value) not in [list, tuple, dict, set]:
                
                kgroup = 0
                vgroup = 0
                
                for items in self.key:
                    kgroup += 1
                
                vgroup += 1
                
                return {'key': kgroup, 'value': vgroup, 'total': kgroup+vgroup}
            
            
            elif type(self.key) not in [list, tuple, dict, set] and type(self.value) in [list, tuple, dict, set]:
                
                kgroup = 0
                vgroup = 0
                
                kgroup += 1
                
                for item in self.value:
                    vgroup += 1
                
                return {'key': kgroup, 'value': vgroup, 'total': kgroup+vgroup}
        
            else:
                elements = False
            
        for item in self.lst:
            pos += 1
            
        return {'key':pos-1, 'value':pos-1, 'total': pos-1+pos-1}
    
    
    def group(self, number=2):
        
        if number == 1:
            return ['key', self.key]
        
        elif number == 2:
            return [['key', self.key], ['value', self.value]]
        
        else:
            raise IndexError("{} is too many groups.".format(number))
    
    
    def iskey(self, key):
        
        if type(self.key) in [list, tuple, dict, set] and type(key) in [list, tuple, dict, set]:
            if type(key) == type(self.key):
                return True
        
        elif key == type(self.key):
            return True
        
        elif key == self.key:
            return True
        
        else:
            return False
    
    
    def isvalue(self, value):
        
        if type(self.value) in [list, tuple, dict, set] and type(value) in [list, tuple, dict, set]:
            if type(value) == type(self.value):
                return True
        
        elif value == type(self.value):
            return True
        
        elif value == self.value:
            return True
        
        else:
            return False
    
    
    def clone(self, key=False, value=False):
        
        if key is True and value is True:
            return [[type(self.key).__name__, self.key], [type(self.value).__name__, self.value]]
        
        elif key is True and value is False:
            return [type(self.key).__name__, self.key]
        
        elif key is False and value is True:
            return [type(self.value).__name__, self.value]
        
        else:
            raise AttributeError("nothing to clone.")
    
    
    def extend(self, key, value):
        first = [self.key, self.value]
        second = [key, value]
        
        self.extended.append(first)
        self.extended.append(second)
        
        return self.extended
    
    
    def exgroups(self):
        
        groups = {}
        pos = 0
        
        if len(self.extended) > 0:
            for group in self.extended:
                pos += 1
                
                groups[f'Group{pos}'] = group
                
            return groups
        
        else:
            raise IndexError("extended group(s) not found.")
    
    
    def get_exgroup(self, group):
        
        if len(self.extended) > 0:
            if group >= 1 <= len(self.extended):
                return self.extended[group-1]
        
        else:
            raise IndexError("extended group(s) not found.")
    
    
    def add_exgroup(self, *args, **kwargs):
        
        if not args or kwargs:
            raise AttributeError("nothing to add to extended group(s).")
        
        elif args and len(args) < 2:
            raise IndexError("need at least two arguments.")
        
        for items in args:
            for item in range(0, len(args), 2):
                self.extended.append([args[item], args[item+1]])
            break
        
        for k, v in kwargs.items():
            self.extended.append([k, v])
        
        return self.extended
    
    
    def is_exkey(self, key):
        
        truth = []
        false = []
        
        while len(self.extended) > 0:
            
            for items in self.extended:
                for item in items:
                    
                    if key == item:
                        truth.append(True)
                    
                    else:
                        false.append(False)
            
            if True in truth:
                return True
            
            else:
                return False

        else:
            raise IndexError("extended group(s) not found.")
    
    
    def is_exvalue(self, value):
        
        truth = []
        false = []
        
        while len(self.extended) > 0:
            
            for items in self.extended:
                for item in items:
                    
                    if value == item:
                        truth.append(True)
                    
                    else:
                        false.append(False)
            
            if True in truth:
                return True
            
            else:
                return False

        else:
            raise IndexError("extended group(s) not found.")
    
    
    def getindex(self, key, value):
        
        grab = []
            
        if key > len(self.lst)-1 and value > len(self.lst)-1:
            raise IndexError("index is too large.")

        elif key <= len(self.lst)-1 and value <= len(self.lst)-1:
            
            grab.append(self.lst[key])
            grab.append(self.lst[value])
                
            return grab
        
        else:
            raise IndexError("indicies out of range.")
    
    
    def exgroup_index(self, key, value):
        
        k = []
        v = []
        
        while len(self.extended) > 0:
            
            for item in range(0, len(self.extended), 2):
                k = self.extended[item]
                v = self.extended[item+1]
            
            return (k[key], v[value])
    
    
    def error(self, default=None):
        
        if len(self.lst) == 0 or len(self.extended) == 0:
            if defaults in None:
                raise ValueError("'key' and 'value' must be set.")
            
            else:
                return defaults
        
        return str(repr("No errors!"))


if __name__ == '__main__':
    pl = pairedlist
    pl.key = 1
    print(pl.key)
    #print(pl.additem())
    #print(pl.delete('name'))
    #print(pl.arithmetic())
    #print(pl.replace(new_key='rayshawn', key=tuple))
    #print(pl.length())
    #print(pl.group())
    #print(pl.iskey(''))
    #print(pl.isvalue(int))
    #print(pl.clone(key=True, value=True))
    #pl.extend('name', 'rayshawn')
    #print(pl.extend('yellow', 'sun'))
    #print(pl.exgroups())
    #print(pl.get_exgroup(1))
    #print(pl.add_exgroup('yellow', 'bone', 'yellow', 'truth'))
    #print(pl.is_exkey('yellow'))
    #print(pl.is_exvalue('bone'))
    #print(pl.getindex(key=0, value=1))
    #print(pl.exgroup_index(0, 1))
    #print(pl.error())

