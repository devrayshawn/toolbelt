

class __unique__(type):
    
    def __new__(cls, name, bases, dct):
        
        dictionary = {}
        new_dict = {}
        
        
        for k, v in dct.items():
            k = str(k)
            dictionary[k] = v
        
        for k, v in dct.items():
            k = str(k)
            new_dict[v] = k
        
        dictionary.update(new_dict)
        Unique = type('unique', (), dictionary)
        
        return Unique


if __name__ == '__main__':
    print(__name__)

