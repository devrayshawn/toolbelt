This package contains three(3) modules: PairedList, unique and xtools.
Firstly, unique is a module which, contains a metaclass called __unique__. 
Secondly, xtools contains methods which, is to act on a given object such as, showing info.
Finally, PairedList creates and modifies lists which are *paired* by key, value.
I hope this package is deemed useful.