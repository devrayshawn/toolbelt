import setuptools



with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="tool_belt",
    version="1.0",
    author="RayshawnLevy",
    author_email="lrayshawn.dev@gmail.com",
    description="A handy package to add toyour toolbelt.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/devrayshawn/toolbelt",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)